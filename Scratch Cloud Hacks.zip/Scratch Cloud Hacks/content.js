chrome.storage.local.get({username: ""}, (usernamedata) => {
    let meta = document.createElement('meta');
    meta.name = 'usernamedata';
    meta.content = usernamedata.username;
    document.head.appendChild(meta);
});
chrome.storage.local.get({project: ""}, (projectdata) => {
    let meta = document.createElement('meta');
    meta.name = 'projectdata';
    const url = new URL(window.location.href);
    const pathname = url.pathname;
    const pathsplit = pathname.split('/')
    const realid = pathsplit[2];
    if (projectdata.project ==  ""){
        meta.content = realid
    }else{
        meta.content = projectdata.project;
    }
    document.head.appendChild(meta);
})