document.getElementById('saveUsername').addEventListener('click', () => {
    const username = document.getElementById('username').value;
    chrome.storage.local.set({ username: username }, () => {
        alert('Username saved!');
    });
});

document.getElementById('saveProject').addEventListener('click', () => {
    const project = document.getElementById('project').value;
    chrome.storage.local.set({ project: project }, () => {
        alert('Project Id saved!');
    });
});
document.addEventListener('DOMContentLoaded', () => {
    chrome.storage.local.get(['username', 'project'], (data) => {
        document.getElementById('username').value = data.username || '';
        document.getElementById('project').value = data.project || '';
    });
});
